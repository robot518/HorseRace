"use strict";
cc._RF.push(module, 'e9980JRNEFBdon0coDZYWaM', 'Player');
// Scripts/Player.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var Player = /** @class */ (function (_super) {
    __extends(Player, _super);
    function Player() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ndLv = null;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    Player.prototype.start = function () {
    };
    // update (dt) {}
    Player.prototype.onCollisionEnter = function (other, obj) {
        this.ndLv.getComponent("Level").onCol();
    };
    __decorate([
        property(cc.Node)
    ], Player.prototype, "ndLv", void 0);
    Player = __decorate([
        ccclass
    ], Player);
    return Player;
}(cc.Component));
exports.default = Player;

cc._RF.pop();