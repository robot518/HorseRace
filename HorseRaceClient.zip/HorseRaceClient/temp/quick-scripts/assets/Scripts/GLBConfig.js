(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scripts/GLBConfig.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '80f8cLrn/NFCpRPhNzHccJ4', 'GLBConfig', __filename);
// Scripts/GLBConfig.ts

Object.defineProperty(exports, "__esModule", { value: true });
/* 存放全局变量 */
var GLB = {
    ip: "47.111.184.119:8081",
    // ip: "47.111.184.119:8082",
    // ip: "127.0.0.1:8082",
    isClickCd: false,
    msgBox: null,
    usrId: null,
    userInfo: null,
    otherInfo: null,
    OpenID: "",
    withCredentials: false,
    iHorse: null,
    bSpView: false,
    //event
    WXLOGIN: "wxLogin",
    MATCH: "match",
    LOSE: "lose",
    QUIT: "quit",
    getTime: function () {
        var s = "[";
        var now = new Date();
        var hh = now.getHours();
        var mm = now.getMinutes();
        var ss = now.getSeconds();
        if (hh < 10)
            s += '0';
        s += hh + ":";
        if (mm < 10)
            s += "0";
        s += mm + ":";
        if (ss < 10)
            s += "0";
        s += ss + "]";
        return s;
    }
};
exports.GLB = GLB;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GLBConfig.js.map
        