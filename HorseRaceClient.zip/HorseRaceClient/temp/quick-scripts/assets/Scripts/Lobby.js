(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Scripts/Lobby.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0760e4+6L5JtKxijKI6UpNW', 'Lobby', __filename);
// Scripts/Lobby.ts

Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var GLBConfig_1 = require("./GLBConfig");
var Socket_1 = require("./Socket");
var Lobby = /** @class */ (function (_super) {
    __extends(Lobby, _super);
    function Lobby() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.ndMatch = null;
        _this.ndShop = null;
        _this.btnMatch = null;
        _this.labTime = null;
        _this.sptHorse = null;
        _this.sptName = null;
        _this.tHorsePic = [];
        _this.tHorseName = [];
        _this.audioClick = null;
        _this._iLv = 1;
        _this._iHorse = 0;
        _this._iTime = 0;
        _this._bMatch = false;
        _this._bTest = false;
        return _this;
    }
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {}
    Lobby.prototype.start = function () {
        this.initCanvas();
        this.initParas();
        this.initEvent();
        this.initShow();
        this.initMsgBox();
        // WS.sendMsg(GLB.WXLOGIN, "qwer&1&2");
    };
    Lobby.prototype.update = function (dt) {
        if (this._bMatch) {
            this._iTime += dt;
            this.showTime();
            if (this._iTime > 10) {
                this._bMatch = false;
                this._iTime = 0;
                Socket_1.WS.sendMsg(GLBConfig_1.GLB.QUIT, GLBConfig_1.GLB.OpenID, this);
                if (this._bannerAd != null)
                    this._bannerAd.hide();
                if (this._videoAd != null)
                    this._videoAd.offClose();
                if (CC_WECHATGAME) {
                    cc.loader.downloader.loadSubpackage('subAtlas', function (err) {
                        if (err) {
                            return console.error(err);
                        }
                        cc.director.loadScene("Level", function (err, scene) {
                            var obj = scene.getChildByName("Canvas").getComponent("Level");
                            Socket_1.WS.obj = obj;
                        });
                    });
                }
                else {
                    cc.director.loadScene("Level", function (err, scene) {
                        var obj = scene.getChildByName("Canvas").getComponent("Level");
                        Socket_1.WS.obj = obj;
                    });
                }
            }
        }
    };
    Lobby.prototype.initCanvas = function () {
        var canvas = this.node.getComponent(cc.Canvas);
        var size = canvas.designResolution;
        var cSize = cc.view.getFrameSize();
        if (cc.sys.os == cc.sys.OS_IOS) { //刘海屏判断
            GLBConfig_1.GLB.bSpView = (cSize.width == 414 && cSize.height == 896) || (cSize.width == 375 && cSize.height == 812);
        }
        // else{
        //     if (cSize.height/cSize.width > 16/9) GLB.bSpView = true;
        // }
        if (GLBConfig_1.GLB.bSpView) {
            canvas.fitWidth = true;
            canvas.fitHeight = true;
        }
        else if (cSize.width / cSize.height >= size.width / size.height) {
            canvas.fitWidth = false;
            canvas.fitHeight = true;
        }
        else {
            canvas.fitWidth = true;
            canvas.fitHeight = false;
        }
    };
    Lobby.prototype.initParas = function () {
        this._bLoaded = false;
        if (GLBConfig_1.GLB.OpenID == "")
            GLBConfig_1.GLB.OpenID = Math.random().toFixed(6);
    };
    Lobby.prototype.initEvent = function () {
        this.btnMatch.on("click", function (argument) {
            this.playSound("click");
            this.onMatch();
        }, this);
        cc.find("btnShop", this.node).on("click", function (argument) {
            this.playSound("click");
            this.ndShop.active = true;
        }, this);
        this.ndShop.on("click", function (params) {
            this.playSound("click");
            this.ndShop.active = false;
        }, this);
        var shopBg = cc.find("bg", this.ndShop);
        cc.find("btn", shopBg).on("click", function (params) {
            this.playSound("click");
            if (this._videoAd != null)
                this._videoAd.show();
        }, this);
        cc.find("right", shopBg).on("click", function (params) {
            this.playSound("click");
            this._iHorse++;
            if (this._iHorse > this.tHorseName.length - 1)
                this._iHorse = 0;
            this.showHorse();
        }, this);
        cc.find("left", shopBg).on("click", function (params) {
            this.playSound("click");
            this._iHorse--;
            if (this._iHorse < 0)
                this._iHorse = this.tHorseName.length - 1;
            this.showHorse();
        }, this);
        if (CC_WECHATGAME) {
            var invite = cc.find("invite", this.ndMatch);
            invite.active = true;
            invite.on("click", function (params) {
                this.onWxEvent("invite");
            }, this);
            var share = cc.find("share", this.node);
            share.active = true;
            share.on("click", function (argument) {
                this.playSound("click");
                this.onWxEvent("share");
            }, this);
            this.onWxEvent("login");
            this.onWxEvent("onShow");
            this.onWxEvent("initBanner");
            this.onWxEvent("initVideo");
        }
    };
    Lobby.prototype.initShow = function () {
        if (this._bTest)
            this.labTime.node.active = true;
    };
    Lobby.prototype.initMsgBox = function () {
        if (GLBConfig_1.GLB.msgBox == null) {
            var msgBox = cc.find("msgBox");
            GLBConfig_1.GLB.msgBox = msgBox;
            cc.game.addPersistRootNode(msgBox);
            cc.find("btn", msgBox).on("click", function (argument) {
                if (GLBConfig_1.GLB.isClickCd)
                    return;
                GLBConfig_1.GLB.isClickCd = true;
                setTimeout(function () {
                    GLBConfig_1.GLB.isClickCd = false;
                }, 1000);
                msgBox.active = false;
                if (Socket_1.WS.ws.readyState !== WebSocket.OPEN)
                    Socket_1.WS.reconnect();
            }, cc.game);
            msgBox.on("click", function (argument) {
                msgBox.active = false;
            }, cc.game);
        }
    };
    Lobby.prototype.onResponse = function (cmd, msg) {
        var args = msg.split("&");
        if (cmd == GLBConfig_1.GLB.MATCH) {
            var res = null;
            if (args.length == 2)
                res = { "nickName": args[0], "avatarUrl": args[1] };
            else
                res = { "nickName": args[1], "avatarUrl": args[2] };
            this.showMatchOther(res);
            if (this._bannerAd != null)
                this._bannerAd.hide();
            if (this._videoAd != null)
                this._videoAd.offClose();
            if (CC_WECHATGAME) {
                cc.loader.downloader.loadSubpackage('subAtlas', function (err) {
                    if (err) {
                        return console.error(err);
                    }
                    cc.director.loadScene("Level", function (err, scene) {
                        var obj = scene.getChildByName("Canvas").getComponent("Level");
                        Socket_1.WS.obj = obj;
                    });
                });
            }
            else {
                cc.director.loadScene("Level", function (err, scene) {
                    var obj = scene.getChildByName("Canvas").getComponent("Level");
                    Socket_1.WS.obj = obj;
                });
            }
        }
    };
    Lobby.prototype.onWxEvent = function (s) {
        if (!CC_WECHATGAME)
            return;
        var self = this;
        switch (s) {
            case "initBanner":
                if (this._bannerAd != null)
                    this._bannerAd.show();
                else {
                    var systemInfo = wx.getSystemInfoSync();
                    this._bannerAd = wx.createBannerAd({
                        adUnitId: 'adunit-68a8244d86c7bf29',
                        style: {
                            left: 0,
                            top: systemInfo.windowHeight - 144,
                            width: 720,
                        }
                    });
                    this._bannerAd.onResize(function (res) {
                        if (self._bannerAd)
                            self._bannerAd.style.top = systemInfo.windowHeight - self._bannerAd.style.realHeight;
                    });
                    this._bannerAd.show();
                    this._bannerAd.onError(function (err) {
                        console.log(err);
                        //无合适广告
                        if (err.errCode == 1004) {
                        }
                    });
                }
                break;
            case "initVideo":
                this._videoAd = wx.createRewardedVideoAd({
                    adUnitId: 'adunit-832cda6401b268ef'
                });
                this._videoAd.onClose(function (res) {
                    if (res && res.isEnded || res === undefined) {
                        GLBConfig_1.GLB.iHorse = self._iHorse;
                        self.ndShop.active = false;
                        self.onMatch();
                    }
                    else {
                    }
                });
                this._videoAd.onError(function (err) {
                    console.log(err);
                });
                break;
            case "invite":
                wx.shareAppMessage({
                    title: "邀请对战！",
                    imageUrl: canvas.toTempFilePathSync({
                        destWidth: 500,
                        destHeight: 400
                    }),
                    query: GLBConfig_1.GLB.OpenID,
                });
                break;
            case "onShow":
                wx.onShow(function (res) {
                    console.log("res.query=", res.query);
                });
                break;
            case "share":
                // var id = '' // 通过 MP 系统审核的图片编号
                // var url = '' // 通过 MP 系统审核的图片地址
                // wx.shareAppMessage({
                //     imageUrlId: id,
                //     imageUrl: url
                // })
                wx.shareAppMessage({
                    title: "你来挑战我啊！",
                    imageUrl: canvas.toTempFilePathSync({
                        destWidth: 500,
                        destHeight: 400
                    })
                });
                break;
            case "showVideo":
                if (self._videoAd != null) {
                    self._videoAd.show()
                        .catch(function (err) {
                        self._videoAd.load()
                            .then(function () { return self._videoAd.show(); });
                    });
                }
                break;
            case "auth":
                wx.getSetting({
                    success: function (res) {
                        if (!res.authSetting['scope.userInfo']) {
                            var dSize = self.node.getComponent(cc.Canvas).designResolution;
                            self.UserInfoButton = wx.createUserInfoButton({
                                type: 'text',
                                text: '',
                                withCredentials: GLBConfig_1.GLB.withCredentials,
                                style: {
                                    left: 0,
                                    top: 0,
                                    width: dSize.width,
                                    height: dSize.height,
                                }
                            });
                            self.UserInfoButton.onTap(function (res) {
                                // console.log("Res = ", res);s
                                if (res.userInfo) {
                                    GLBConfig_1.GLB.userInfo = res.userInfo;
                                    var str = GLBConfig_1.GLB.OpenID + "&" + res.userInfo.nickName + "&" + res.userInfo.avatarUrl;
                                    if (Socket_1.WS.sendMsg(GLBConfig_1.GLB.WXLOGIN, str)) {
                                        // self.onMatch();
                                        self.UserInfoButton.hide();
                                    }
                                }
                            });
                        }
                        else {
                            wx.getUserInfo({
                                withCredentials: GLBConfig_1.GLB.withCredentials,
                                success: function (res) {
                                    // console.log("Res = ", res);
                                    GLBConfig_1.GLB.userInfo = res.userInfo;
                                    var str = GLBConfig_1.GLB.OpenID + "&" + res.userInfo.nickName + "&" + res.userInfo.avatarUrl;
                                    Socket_1.WS.sendMsg(GLBConfig_1.GLB.WXLOGIN, str);
                                }
                            });
                        }
                    }
                });
                break;
            case "login":
                // cc.sys.localStorage.setItem("OpenID", null);
                GLBConfig_1.GLB.OpenID = cc.sys.localStorage.getItem("OpenID");
                // console.log("OpenID2 = ", GLB.OpenID);
                if (GLBConfig_1.GLB.OpenID) {
                    if (!GLBConfig_1.GLB.userInfo)
                        this.onWxEvent("auth");
                }
                else {
                    wx.login({
                        success: function (res) {
                            if (res.code) {
                                //发起网络请求
                                // console.log("code = ", res.code);
                                wx.request({
                                    // url: 'http://'+GLB.ip,
                                    // url: "https://websocket.windgzs.cn/HorseRace/",
                                    url: "https://websocket.guanzhiwangluogongyi.vip/",
                                    data: {
                                        code: res.code
                                    },
                                    success: function (response) {
                                        // console.log("success response = ", response);
                                        // console.log("OpenID = ", response.data);
                                        GLBConfig_1.GLB.OpenID = response.data;
                                        cc.sys.localStorage.setItem("OpenID", response.data);
                                        self.onWxEvent("auth");
                                    },
                                    fail: function (response) {
                                        console.log("fail response = ", response);
                                    }
                                });
                            }
                            else {
                                console.log('登录失败！' + res.errMsg);
                            }
                        }
                    });
                }
                // wx.checkSession({ //用于检测SessionKey是否过期
                //     success () {
                //         //session_key 未过期，并且在本生命周期一直有效
                //         if (!GLB.userInfo) this.onWxEvent("auth");
                //     },
                //     fail () {
                //         // session_key 已经失效，需要重新执行登录流程
                //     }
                // })
                break;
        }
    };
    Lobby.prototype.playSound = function (sName) {
        if (sName == "click")
            cc.audioEngine.play(this.audioClick, false, 1);
    };
    Lobby.prototype.onMatch = function () {
        if (Socket_1.WS.sendMsg(GLBConfig_1.GLB.MATCH, GLBConfig_1.GLB.OpenID, this))
            this._bMatch = true;
        this._iTime = 0;
        this.ndMatch.active = true;
        var me = this.ndMatch.getChildByName("me");
        var str = "";
        if (GLBConfig_1.GLB.userInfo) {
            str = this.getStrName(GLBConfig_1.GLB.userInfo.nickName);
            cc.loader.load({ url: GLBConfig_1.GLB.userInfo.avatarUrl, type: "png" }, function (error, texture) {
                if (error) {
                    console.log("load pic error", error);
                    return;
                }
                me.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
            });
        }
        me.getChildByName("name").getComponent(cc.Label).string = str;
    };
    Lobby.prototype.showMatchOther = function (res) {
        GLBConfig_1.GLB.otherInfo = res;
        if (GLBConfig_1.GLB.otherInfo && GLBConfig_1.GLB.otherInfo instanceof Object) {
            var other_1 = this.ndMatch.getChildByName("other");
            other_1.getChildByName("name").getComponent(cc.Label).string = this.getStrName(GLBConfig_1.GLB.otherInfo.nickName);
            if (GLBConfig_1.GLB.otherInfo.avatarUrl) {
                cc.loader.load({ url: GLBConfig_1.GLB.otherInfo.avatarUrl, type: "png" }, function (error, texture) {
                    if (error) {
                        console.log("load pic error", error);
                        return;
                    }
                    other_1.getComponent(cc.Sprite).spriteFrame = new cc.SpriteFrame(texture);
                });
            }
        }
    };
    Lobby.prototype.getStrName = function (s) {
        if (s && s.length > 5)
            s = s.substring(0, 5) + "...";
        return s || "";
    };
    Lobby.prototype.showHorse = function () {
        this.sptHorse.spriteFrame = this.tHorsePic[this._iHorse];
        this.sptName.spriteFrame = this.tHorseName[this._iHorse];
    };
    Lobby.prototype.showTime = function () {
        this.labTime.string = this._iTime.toFixed(0);
    };
    __decorate([
        property(cc.Node)
    ], Lobby.prototype, "ndMatch", void 0);
    __decorate([
        property(cc.Node)
    ], Lobby.prototype, "ndShop", void 0);
    __decorate([
        property(cc.Node)
    ], Lobby.prototype, "btnMatch", void 0);
    __decorate([
        property(cc.Label)
    ], Lobby.prototype, "labTime", void 0);
    __decorate([
        property(cc.Sprite)
    ], Lobby.prototype, "sptHorse", void 0);
    __decorate([
        property(cc.Sprite)
    ], Lobby.prototype, "sptName", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], Lobby.prototype, "tHorsePic", void 0);
    __decorate([
        property(cc.SpriteFrame)
    ], Lobby.prototype, "tHorseName", void 0);
    __decorate([
        property({
            type: cc.AudioClip
        })
    ], Lobby.prototype, "audioClick", void 0);
    Lobby = __decorate([
        ccclass
    ], Lobby);
    return Lobby;
}(cc.Component));
exports.default = Lobby;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Lobby.js.map
        